import 'package:ace_routes/controller/audio_controller.dart';
import 'package:flutter/material.dart';

class AudioRecord extends StatefulWidget {
  const AudioRecord({super.key});

  @override
  State<AudioRecord> createState() => _AudioRecordState();
}

class _AudioRecordState extends State<AudioRecord> {
  final AudioController _controller = AudioController();

  @override
  void initState() {
    super.initState();
    _initController();
  }

  Future<void> _initController() async {
    await _controller.init();
    setState(() {});
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Audio',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Color.fromARGB(255, 76, 81, 175),
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Container(
        width: double.infinity,
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height: 20),
            Icon(
              Icons.mic,
              size: 100,
              color: _controller.isRecording ? Colors.green : Colors.black,
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _controller.isRecording
                  ? () async {
                      await _controller.stopRecording();
                      setState(() {});
                    }
                  : () async {
                      await _controller.startRecording();
                      setState(() {});
                    },
              child: Text(_controller.isRecording
                  ? 'Stop Recording'
                  : 'Start Recording'),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.separated(
                itemCount: _controller.recordings.length,
                separatorBuilder: (context, index) =>
                    SizedBox(height: 10), // Space between items

                itemBuilder: (context, index) {
                  final recordingPath = _controller.recordings[index];
                  final isPlaying = _controller.playingPath == recordingPath;
                  return Container(
                    color: const Color.fromARGB(255, 211, 211, 211),
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 0, right: 0, top: 8, bottom: 8),
                      child: ListTile(
                        title: GestureDetector(
                            onTap: () {},
                            child: Text('Recording ${index + 1}')),
                        leading: IconButton(
                          icon: Icon(
                            isPlaying
                                ? Icons.pause_circle_filled
                                : Icons.play_arrow,
                            color: Colors.black,
                            size: 50,
                          ),
                          onPressed: () async {
                            await _controller.togglePlayback(
                              recordingPath,
                              () => setState(() {}),
                            );
                          },
                        ),
                        trailing: IconButton(
                          icon: Icon(
                            Icons.delete,
                            color: Colors.red,
                            size: 40,
                          ),
                          onPressed: () async {
                            await _controller.deleteRecording(recordingPath);
                            setState(() {});
                          },
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
