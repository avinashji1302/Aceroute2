import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:get/get.dart';

class BarcodeController extends GetxController {
  Future<void> scanBarcode() async {
    String barcodeScanRes;
    String _scanResult = 'Unknown';

    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
        "#ff6666", // Color of the scanning line
        "Cancel", // Text for the cancel button
        true, // Whether to display the flash icon
        ScanMode.BARCODE, // Scan mode (can be QR or BARCODE)
      );
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }

    // If the scan result is not "-1", show the result
    // if (!mounted) return;

    _scanResult = barcodeScanRes;
  }
}
