import 'package:flutter/material.dart';

class MyColors {
  static final Color blueColor = Colors.blue[900]!;
  static final Color whiteColor = Colors.blue[900]!;
  static final Color blackColor = Colors.blue[900]!;
  static final Color greenColor = Colors.green;
}

final Url = "";
