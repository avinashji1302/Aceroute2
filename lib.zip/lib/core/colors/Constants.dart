import 'package:flutter/material.dart';

class MyColors {
  static final Color blueColor = Colors.blue[900]!;
  static final Color whiteColor = Colors.white!;
  static final Color blackColor = Colors.blue[900]!;
  static final Color greenColor = Colors.green;
}

/*String baseUrlDb = "";
String nspDb = "";
String token = "";
String ridDb = "";
String geoDb = "";*/

String baseUrl = "";
String nsp = "";
String token = "";
String rid = "";
String geo = "";
