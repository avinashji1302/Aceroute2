
import 'package:sqflite/sqflite.dart';

import '../../model/GTypeModel.dart';
import '../databse_helper.dart';

class GTypeTable {
  static const String tableName = 'gen_type';

  // Create the gen_type table
  static Future<void> onCreate(Database db) async {
    await db.execute('''
    CREATE TABLE $tableName (
      id TEXT PRIMARY KEY,
      name TEXT,
      typeId TEXT,
      capacity TEXT,
      detail TEXT,
      externalId TEXT,
      updateTimestamp TEXT,
      updatedBy TEXT
    )
  ''');
  }


  // Upgrade logic for the gen_type table
  static Future<void> onUpgrade(Database db) async {
    await onCreate(db); // Re-create the table if upgrading
  }

  // Insert GType into the gen_type table
  static Future<void> insertGType(GTypeModel gtype) async {
    final db = await DatabaseHelper().database;
    fetchGTypes(); // Optional: Refresh GTypes after insertion
    await db.insert(
      tableName,
      gtype.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Fetch all GTypes
  static Future<List<GTypeModel>> fetchGTypes() async {
    final db = await DatabaseHelper().database;
    final List<Map<String, dynamic>> maps = await db.query(tableName);
    return List.generate(maps.length, (i) => GTypeModel.fromJson(maps[i]));
  }

  // Fetch GType by ID
  static Future<GTypeModel?> fetchGTypeById(String id) async {
    final db = await DatabaseHelper().database;
    final List<Map<String, dynamic>> maps = await db.query(
      tableName,
      where: 'id = ?', // SQL WHERE clause
      whereArgs: [id], // Arguments for the WHERE clause
    );

    // If data exists, return the first record as a GTypeModel object
    if (maps.isNotEmpty) {
      print("success in getting $id");
      return GTypeModel.fromJson(maps.first);
    }else{
      print("mot found");
    }

    // If no data found, return null
    return null;
  }

  // Clear all GTypes
  static Future<void> clearGTypes() async {
    final db = await DatabaseHelper().database;
    await db.delete(tableName);
  }
}
