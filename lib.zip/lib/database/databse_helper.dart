import 'dart:async';
import 'package:ace_routes/model/token_get_model.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;

  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'api_data.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE api_data (
        requestId INTEGER PRIMARY KEY,
        responderName TEXT,
        geoLocation TEXT,
        nspId TEXT,
        gpsSync INTEGER,
        locationChange INTEGER,
        shiftDateLock INTEGER,
        shiftError INTEGER,
        endValue INTEGER,
        speed INTEGER,
        multiLeg INTEGER,
        uiConfig TEXT,
        token TEXT
      )
    ''');
  }

  // Insert data into the database
  Future<void> insertData(TokenApiReponse response) async {
    final db = await database;
    await db.insert(
      'api_data',
      response.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Fetch all data from the database
  Future<List<TokenApiReponse>> fetchData() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('api_data');

    

    return List.generate(maps.length, (i) {
      return TokenApiReponse.fromMap(maps[i]);
    });
  }

  // Clear all data
  Future<void> clearData() async {
    final db = await database;
    await db.delete('api_data');
  }
}
