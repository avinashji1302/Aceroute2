import 'package:ace_routes/controller/fontSizeController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:syncfusion_flutter_signaturepad/signaturepad.dart';

class Signature extends StatefulWidget {
  const Signature({super.key});

  @override
  State<Signature> createState() => _SignatureState();
}

class _SignatureState extends State<Signature> {
   final fontSizeController = Get.find<FontSizeController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Signature here',
          style: TextStyle(color: Colors.white,fontSize: fontSizeController.fontSize),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Container(
        child: Column(children: [
          SizedBox(height: 10,),
          Text("Sign here" , style: TextStyle(color: Colors.black,fontSize: fontSizeController.fontSize),),
          Card(
            elevation: 20,
            child: SfSignaturePad(
              minimumStrokeWidth: 1,
              maximumStrokeWidth: 3,
              strokeColor: Colors.blue,
              backgroundColor: Colors.white,
            ),
          ),
        ]),
      
        
      ),
    );
  }
}